import asyncio
import os
import re
import threading
import unicodedata
from typing import Union

import pyJianYingDraft as draft
from utils.formatters import safe_tim


# 字幕几何口径以**剪映自己写出的草稿**为准（2026-09-17 实测）。
# 单位见 vendor/pyJianYingDraft/segment.py 的 `ClipSettings.transform_y`：它是
# 「半个画布高」，同文件 docstring 亦注明「剪映导入的字幕似乎取此值为 -0.8」。
# 旧值 -1000.0 是误抄 `script_file.import_srt` 的形参默认值 —— 它把字幕推到画布
# 外，成片里根本看不见。当前治理基线要求字幕统一画布内可见、加粗。
# 字号按用户 2026-09-17 定案**统一 8 号**（此前曾按历史稿实测取 5.0，用户纠正）。
# 2026-10-15 卫品反馈「字幕往上移」：-0.8 贴底太低，上移到 -0.55（仍在画布内）。
# 运营口头说的「Y=-1000」是剪映界面像素口径，不能直接写进 transform_y。
DEFAULT_SUBTITLE_FONT_SIZE = 8.0
DEFAULT_SUBTITLE_BOLD = True
DEFAULT_SUBTITLE_X = 0.0
DEFAULT_SUBTITLE_Y = -0.55


def _clean_subtitle_text(value: str) -> str:
    """Remove Chinese/English punctuation from subtitle display text."""
    chars = []
    for char in str(value or ""):
        if unicodedata.category(char).startswith("P"):
            continue
        chars.append(char)
    return re.sub(r"[ \t]+", " ", "".join(chars)).strip()


def _is_subtitle_track(track_name: str) -> bool:
    """Recognize the common subtitle/caption track aliases used by callers."""
    key = str(track_name or "").strip().lower()
    return key in {"subtitles", "subtitle", "captions", "caption", "字幕"}


class TextOpsMixin:
    """
    JyProject 的文本与字幕 Mixin。
    """

    def add_text_simple(
        self,
        text: str,
        start_time: Union[str, int] = None,
        duration: Union[str, int] = "3s",
        track_name: str = "Subtitles",
        **kwargs,
    ):
        if start_time is None:
            start_time = self.get_track_duration(track_name)
        self._ensure_track(draft.TrackType.text, track_name)

        if _is_subtitle_track(track_name):
            text = _clean_subtitle_text(text)

        start_us = safe_tim(start_time)
        dur_us = safe_tim(duration)

        # 兼容高层参数：动画参数不透传给 TextSegment，避免底层 __init__ 报 unexpected kw。
        anim_in = kwargs.pop("anim_in", None)
        anim_out = kwargs.pop("anim_out", None)
        anim_loop = kwargs.pop("anim_loop", None)
        anim_in_duration = kwargs.pop("anim_in_duration", None)
        anim_out_duration = kwargs.pop("anim_out_duration", None)
        anim_loop_duration = kwargs.pop("anim_loop_duration", None)

        # 仅透传 TextSegment 支持的字段
        allowed_keys = {"font", "style", "clip_settings", "border", "background", "shadow", "rich_spans"}
        text_kwargs = {k: v for k, v in kwargs.items() if k in allowed_keys}
        # 统一默认字幕样式：字号 8 + 加粗 + 黑色描边
        if "style" not in text_kwargs:
            text_kwargs["style"] = draft.TextStyle(
                size=DEFAULT_SUBTITLE_FONT_SIZE, bold=DEFAULT_SUBTITLE_BOLD)
        if "border" not in text_kwargs:
            text_kwargs["border"] = draft.TextBorder(color=(0.0, 0.0, 0.0), alpha=1.0, width=40.0)
        if "clip_settings" not in text_kwargs:
            text_kwargs["clip_settings"] = draft.ClipSettings(
                transform_x=DEFAULT_SUBTITLE_X, transform_y=DEFAULT_SUBTITLE_Y)

        seg = draft.TextSegment(text, draft.Timerange(start_us, dur_us), **text_kwargs)

        # 为动画名称做同义词+模糊解析，支持如 "Typewriter" -> "复古打字机"
        if anim_in:
            intro_enum = self._resolve_enum(draft.TextIntro, str(anim_in))
            if intro_enum:
                seg.add_animation(intro_enum, duration=anim_in_duration)
        if anim_out:
            outro_enum = self._resolve_enum(draft.TextOutro, str(anim_out))
            if outro_enum:
                seg.add_animation(outro_enum, duration=anim_out_duration)
        if anim_loop:
            loop_enum = self._resolve_enum(draft.TextLoopAnim, str(anim_loop))
            if loop_enum:
                seg.add_animation(loop_enum, duration=anim_loop_duration)

        self.script.add_segment(seg, track_name)
        return seg

    def add_rich_text(
        self,
        text: str,
        highlights: list,
        start_time: Union[str, int] = None,
        duration: Union[str, int] = "3s",
        track_name: str = "Subtitles",
        **kwargs,
    ):
        """
        添加富文本字幕，支持按关键词高亮。
        highlights 格式: [{"word": "99%", "color": (1,0,0), "bold": True}, ...]
        """
        if _is_subtitle_track(track_name):
            text = _clean_subtitle_text(text)
        spans = []
        for h in highlights:
            word = h.get("word")
            if not word:
                continue

            start = 0
            while True:
                idx = text.find(word, start)
                if idx == -1:
                    break

                span = draft.RichTextSpan(
                    idx,
                    idx + len(word),
                    color=h.get("color"),
                    size=h.get("size"),
                    bold=h.get("bold"),
                    italic=h.get("italic"),
                    underline=h.get("underline"),
                )
                spans.append(span)
                start = idx + len(word)

        kwargs["rich_spans"] = spans
        return self.add_text_simple(text, start_time, duration, track_name, **kwargs)

    def set_subtitle_keywords(self, keywords_config: dict):
        """设置字幕关键词高亮配置，注入 draft_info.json 的 config 节点"""
        self.script.subtitle_keywords_config = keywords_config

    def add_narrated_subtitles(
        self,
        text: str,
        speaker: str = "zh_female_xiaopengyou",
        start_time: Union[str, int] = None,
        track_name: str = "Subtitles",
    ):
        if start_time is None:
            start_time = self.get_track_duration(track_name)
        curr_us = safe_tim(start_time)
        chosen_backend = None

        parts = [p for p in re.split(r"([，。！？、\n\r]+)", text) if p.strip()]
        sentences = []
        for i in range(0, len(parts), 2):
            s = parts[i]
            if i + 1 < len(parts):
                s += parts[i + 1]
            sentences.append(s.strip())

        for s in sentences:
            clean_text = s.rstrip("，。！？、\n\r ")
            if not clean_text:
                continue

            audio_seg, backend_used = self.add_tts_intelligent(
                clean_text,
                speaker=speaker,
                start_time=curr_us,
                tts_backend=chosen_backend,
                allow_fallback=(chosen_backend is None),
                return_backend=True,
            )
            if audio_seg:
                if chosen_backend is None:
                    chosen_backend = backend_used
                actual_dur_us = audio_seg.target_timerange.duration
                clip_settings = draft.ClipSettings(
                    transform_x=DEFAULT_SUBTITLE_X, transform_y=DEFAULT_SUBTITLE_Y)
                subtitle_style = draft.TextStyle(
                    size=DEFAULT_SUBTITLE_FONT_SIZE, bold=DEFAULT_SUBTITLE_BOLD)
                subtitle_border = draft.TextBorder(color=(0.0, 0.0, 0.0), alpha=1.0, width=40.0)
                self.add_text_simple(
                    clean_text,
                    start_time=curr_us,
                    duration=actual_dur_us,
                    track_name=track_name,
                    clip_settings=clip_settings,
                    style=subtitle_style,
                    border=subtitle_border,
                )
                curr_us += actual_dur_us + 100000
            else:
                if chosen_backend is not None:
                    raise RuntimeError(
                        f"TTS segment failed under locked backend '{chosen_backend}'. "
                        "Stopped to avoid mixed voice providers."
                    )
        return curr_us

    def add_tts_intelligent(
        self,
        text: str,
        speaker: str = "zh_male_huoli",
        start_time: Union[str, int] = None,
        track_name: str = "VoiceOver",
        tts_backend: str = None,
        allow_fallback: bool = True,
        return_backend: bool = False,
    ):
        import uuid

        from universal_tts import generate_voice_with_meta

        if start_time is None:
            start_time = self.get_track_duration(track_name)

        temp_dir = os.path.join(self.root, self.name, "temp_assets")
        os.makedirs(temp_dir, exist_ok=True)
        output_file = os.path.join(temp_dir, f"tts_{uuid.uuid4().hex[:8]}.ogg")

        async def _generate():
            return await generate_voice_with_meta(
                text,
                output_file,
                speaker,
                backend=tts_backend,
                allow_fallback=allow_fallback,
                sami_retries=2,
            )

        try:
            asyncio.get_running_loop()
            loop_running = True
        except Exception:
            loop_running = False

        if loop_running:
            box = {"path": None, "err": None}

            def _worker():
                try:
                    box["path"] = asyncio.run(_generate())
                except Exception as e:
                    box["err"] = e

            t = threading.Thread(target=_worker, daemon=True)
            t.start()
            t.join()
            if box["err"] is not None:
                raise box["err"]
            actual_path, backend_used = box["path"] if box["path"] else (None, None)
        else:
            actual_path, backend_used = asyncio.run(_generate())

        if not actual_path:
            return (None, None) if return_backend else None
        seg = self.add_media_safe(actual_path, start_time, track_name=track_name)
        return (seg, backend_used) if return_backend else seg

    async def add_tts_intelligent_async(
        self,
        text: str,
        speaker: str = "zh_male_huoli",
        start_time: Union[str, int] = None,
        track_name: str = "VoiceOver",
    ):
        import uuid

        from universal_tts import generate_voice

        if start_time is None:
            start_time = self.get_track_duration(track_name)

        temp_dir = os.path.join(self.root, self.name, "temp_assets")
        os.makedirs(temp_dir, exist_ok=True)
        output_file = os.path.join(temp_dir, f"tts_{uuid.uuid4().hex[:8]}.ogg")
        actual_path = await generate_voice(text, output_file, speaker)
        if not actual_path:
            return None
        return self.add_media_safe(actual_path, start_time, track_name=track_name)

import argparse
import csv
import ipaddress
import os
import re
from typing import Any, Dict, Optional
from urllib.parse import parse_qs, urlparse

import requests
from utils.config import CONFIG
from utils.logging_utils import setup_logger

SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORKSPACE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(SKILL_ROOT)))
# Keep runtime cache writable when the skill is extracted from a ZIP or run from
# a read-only workspace; allow operators to choose a shared cache explicitly.
CACHE_DIR = os.environ.get("JY_CLOUD_CACHE_DIR", os.path.join(SKILL_ROOT, ".cache", "cloud"))
MAX_DOWNLOAD_BYTES = int(CONFIG.cloud_max_mb * 1024 * 1024)
ALLOWED_SCHEMES = {"http", "https"}
logger = setup_logger("cloud_manager")

JY_MGET_ITEM_URL = (
    "https://lv-api-sinfonlinea.ulikecam.com/artist/v1/effect/mget_item"
    "?effect_sdk_version=16.4.0"
    "&channel=jianyingpro_0"
    "&aid=3704"
    "&opengl_version=3.3"
    "&device_id=1053764930506284"
    "&cpu=12th%20Gen%20Intel(R)%20Core(TM)%20i5-12400F"
    "&version_name=5.9.0"
    "&language=zh-Hans"
    "&region=CN"
    "&version_code=5.9.0"
    "&device_platform=windows"
    "&biz_id=2"
    "&subdivision_id="
    "&gpu=NVIDIA%20GeForce%20RTX%203060"
    "&version_code_num=329984"
    "&device_type=x86_64"
)
JY_API_HEADERS = {
    "User-Agent": "JianyingPro/5.9.0.11632 (Windows 10.0.19045; app_id:3704)",
    "Accept": "application/json, text/plain, */*",
    "Content-Type": "application/json",
}


class CloudManager:
    def __init__(self):
        self.assets = self._load_database()
        if not os.path.exists(CACHE_DIR):
            os.makedirs(CACHE_DIR)

    def _load_database(self) -> Dict[str, dict]:
        assets: Dict[str, dict] = {}
        db_files = ["cloud_music_library.csv", "cloud_video_assets.csv", "cloud_sound_effects.csv"]

        for db_name in db_files:
            path = os.path.join(SKILL_ROOT, "data", db_name)
            if not os.path.exists(path):
                continue

            try:
                with open(path, "r", encoding="utf-8") as f:
                    lines = [line for line in f.readlines() if not line.startswith("#")]
                    reader = csv.DictReader(lines)
                    for row in reader:
                        eid = row.get("id") or row.get("music_id") or row.get("effect_id")
                        if not eid:
                            continue
                        name = row.get("name") or row.get("title") or row.get("name_hint") or ""
                        dur = row.get("duration_s") or row.get("duration")
                        assets[str(eid)] = {
                            "id": str(eid),
                            "name": str(name),
                            "url": row.get("url", ""),
                            "duration_s": (
                                float(dur)
                                if dur and str(dur).replace(".", "", 1).isdigit()
                                else None
                            ),
                            "type": row.get("type") or row.get("categories", "unknown"),
                            "source_db": db_name,
                        }
            except Exception as e:
                logger.warning("Error loading %s: %s", db_name, e)

        if assets:
            logger.info("Cloud Manager indexed %d items.", len(assets))
        return assets

    def find_asset(self, query: str) -> Optional[dict]:
        """
        Find by ID or fuzzy name.
        Rows without static URL are still usable because the runtime can resolve fresh URLs by ID.
        """
        if query in self.assets:
            return self.assets[query]

        q = str(query).lower()
        for asset in self.assets.values():
            if q in str(asset.get("name", "")).lower():
                return asset
        return None

    def get_asset_duration(self, query: str) -> Optional[float]:
        asset = self.find_asset(query)
        if asset:
            return asset.get("duration_s")
        return None

    def get_url_from_logs(self, effect_id: str) -> Optional[str]:
        log_files = [
            os.path.join(WORKSPACE_ROOT, "mitmdump_assets_capture.log"),
            os.path.join(WORKSPACE_ROOT, "mitmdump_media_full.log"),
        ]

        for log_path in log_files:
            if not os.path.exists(log_path):
                continue
            with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            id_pattern = f'"(?:effect_id|id)":"{effect_id}"'
            matches = list(re.finditer(id_pattern, content))
            if not matches:
                continue

            for m in reversed(matches):
                region = content[m.end() : m.end() + 10000]
                url_match = re.search(
                    r'https?://[^\s"\'\]]+(?:\.mp4|\.webm|\.zip|\.7z|a=4066)[^\s"\'\]]*',
                    region,
                    re.IGNORECASE,
                )
                if url_match:
                    return url_match.group(0).replace("\\u0026", "&").replace("\\/", "/")
        return None

    def _extract_urls(self, data: Any) -> list[str]:
        urls: list[str] = []

        def walk(obj: Any) -> None:
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if key == "item_urls" and isinstance(value, list):
                        urls.extend(str(v) for v in value if isinstance(v, str))
                    elif key in {"url", "video_url", "download_url"} and isinstance(value, str):
                        urls.append(value)
                    else:
                        walk(value)
            elif isinstance(obj, list):
                for value in obj:
                    walk(value)

        walk(data)
        return [
            url.replace("\\u0026", "&").replace("\\/", "/")
            for url in urls
            if url.startswith("http")
        ]

    def _resolve_url_by_id(self, asset: dict) -> Optional[str]:
        eid = asset.get("id")
        if not eid:
            return None

        bodies = [
            {"items": [{"id": eid, "effect_type": 4, "source": 3}]},
            {"items": [{"id": eid, "effect_type": 4}]},
            {"items": [{"effect_id": eid, "effect_type": 4, "source": 3}]},
            {"items": [{"effect_id": eid, "effect_type": 4}]},
        ]

        for body in bodies:
            try:
                res = requests.post(JY_MGET_ITEM_URL, headers=JY_API_HEADERS, json=body, timeout=20)
                res.raise_for_status()
                data = res.json()
            except Exception as e:
                logger.debug("Cloud URL resolve attempt failed for ID %s: %s", eid, e)
                continue

            for url in self._extract_urls(data):
                if self._is_safe_download_url(url):
                    asset["url"] = url
                    logger.info("Resolved fresh cloud URL for ID %s.", eid)
                    return url
        return None

    def _is_safe_download_url(self, url: str) -> bool:
        try:
            parsed = urlparse(url)
            if parsed.scheme.lower() not in ALLOWED_SCHEMES:
                return False
            host = (parsed.hostname or "").strip().lower()
            if not host:
                return False
            if host in {"localhost", "127.0.0.1", "::1"}:
                return False
            try:
                ip = ipaddress.ip_address(host)
                if ip.is_private or ip.is_loopback or ip.is_link_local:
                    return False
            except ValueError:
                pass
            return True
        except Exception:
            return False

    def _validate_response_headers(self, res: requests.Response) -> bool:
        content_type = (res.headers.get("Content-Type") or "").lower()
        if content_type.startswith("text/html") or content_type.startswith("application/json"):
            return False
        if content_type and not (
            "video/" in content_type
            or "audio/" in content_type
            or "application/octet-stream" in content_type
            or "application/zip" in content_type
            or "binary/octet-stream" in content_type
        ):
            return False
        content_length = res.headers.get("Content-Length")
        if content_length and content_length.isdigit() and int(content_length) > MAX_DOWNLOAD_BYTES:
            return False
        return True

    def _is_audio_asset(self, asset: dict) -> bool:
        source_db = str(asset.get("source_db", "")).lower()
        db_type = str(asset.get("type", "")).lower()
        if source_db in {"cloud_music_library.csv", "cloud_sound_effects.csv"}:
            return True
        return any(k in db_type for k in ["music", "audio", "sound", "bgm", "音效", "歌曲", "歌"])

    def _infer_extension(self, asset: dict, url: str, content_type: str = "") -> str:
        mime_type_hint = ""
        try:
            parsed = urlparse(url)
            mime_type_hint = (parse_qs(parsed.query).get("mime_type", [""])[0] or "").lower()
        except Exception:
            mime_type_hint = ""

        content_type = (content_type or "").lower()
        is_audio = self._is_audio_asset(asset)

        if "audio" in mime_type_hint or content_type.startswith("audio/"):
            if "mpeg" in mime_type_hint or "mpeg" in content_type:
                return ".mp3"
            if "wav" in mime_type_hint or "wav" in content_type:
                return ".wav"
            if "ogg" in mime_type_hint or "ogg" in content_type:
                return ".ogg"
            return ".m4a"

        if "video" in mime_type_hint or content_type.startswith("video/"):
            return ".mp4"

        if is_audio:
            return ".m4a"
        return ".mp4"

    def download_asset(self, query: str, force: bool = False) -> Optional[str]:
        asset = self.find_asset(query)
        if not asset:
            logger.warning("Cloud Asset '%s' not found in database.", query)
            return None

        eid = asset["id"]
        safe_name = "".join([c for c in asset["name"] if c.isalnum() or c in (" ", "_")]).strip()

        resolved_fresh = False
        url = asset.get("url")
        if (not url) or force:
            url = self.get_url_from_logs(eid)
        if not url:
            url = self._resolve_url_by_id(asset)
            resolved_fresh = bool(url)

        if not url:
            logger.warning("No valid download URL found for ID %s.", eid)
            return None
        if not self._is_safe_download_url(url):
            logger.warning("Unsafe download URL blocked for ID %s: %s", eid, url)
            return None

        ext = self._infer_extension(asset, url=url)
        local_filename = f"{eid}_{safe_name}{ext}"
        local_path = os.path.join(CACHE_DIR, local_filename)
        legacy_mp4_path = os.path.join(CACHE_DIR, f"{eid}_{safe_name}.mp4")

        if not force:
            if os.path.exists(local_path):
                return local_path
            if ext != ".mp4" and os.path.exists(legacy_mp4_path):
                try:
                    os.replace(legacy_mp4_path, local_path)
                    return local_path
                except Exception:
                    return legacy_mp4_path

        urls_to_try = [url]
        if not resolved_fresh:
            fresh_url = self._resolve_url_by_id(asset)
            if fresh_url and fresh_url not in urls_to_try:
                urls_to_try.append(fresh_url)

        for attempt_url in urls_to_try:
            if not self._is_safe_download_url(attempt_url):
                logger.warning("Unsafe download URL blocked for ID %s: %s", eid, attempt_url)
                continue
            logger.info("Downloading Cloud Asset: %s", asset["name"])
            res = None
            try:
                res = requests.get(attempt_url, stream=True, timeout=60)
                res.raise_for_status()
                if not self._validate_response_headers(res):
                    logger.warning("Download blocked by header validation for ID %s.", eid)
                    continue

                ext_from_headers = self._infer_extension(
                    asset, url=attempt_url, content_type=(res.headers.get("Content-Type") or "")
                )
                if ext_from_headers != ext:
                    ext = ext_from_headers
                    local_filename = f"{eid}_{safe_name}{ext}"
                    local_path = os.path.join(CACHE_DIR, local_filename)

                tmp_path = local_path + ".part"
                total = 0
                with open(tmp_path, "wb") as f:
                    for chunk in res.iter_content(chunk_size=32768):
                        if not chunk:
                            continue
                        total += len(chunk)
                        if total > MAX_DOWNLOAD_BYTES:
                            raise ValueError(f"Download exceeds size limit: {MAX_DOWNLOAD_BYTES} bytes")
                        f.write(chunk)
                os.replace(tmp_path, local_path)
                logger.info("Download finished: %s", local_path)
                return local_path
            except Exception as e:
                part = local_path + ".part"
                if os.path.exists(part):
                    try:
                        os.remove(part)
                    except Exception:
                        pass
                logger.error("Download error: %s", e)
            finally:
                if res is not None:
                    try:
                        res.close()
                    except Exception:
                        pass
        return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="JianYing Cloud Asset Manager")
    parser.add_argument("query", help="ID or Name of the asset")
    parser.add_argument("--force", action="store_true", help="Force redownload")
    args = parser.parse_args()

    manager = CloudManager()
    path = manager.download_asset(args.query, args.force)
    if path:
        print(f"RESULT_PATH|{path}")
